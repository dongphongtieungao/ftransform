#!/bin/bash
set -euo pipefail

NAME_DIR=/hadoop/dfs/name

echo "[sk-namenode] Using HADOOP_HOME=${HADOOP_HOME:-<unset>}"
echo "[sk-namenode] PATH=$PATH"

if [ ! -f "$NAME_DIR/current/VERSION" ]; then
  echo "[sk-namenode] NameNode not formatted yet (missing current/VERSION). Formatting..."
  hdfs namenode -format -force -nonInteractive
  echo "[sk-namenode] Format completed."
else
  echo "[sk-namenode] NameNode already formatted. Skipping format."
fi

echo "[sk-namenode] Starting NameNode..."
exec hdfs namenode

#!/bin/bash
set -euo pipefail

echo "[hbase-master] HBASE_HOME=${HBASE_HOME:-<unset>}"
echo "[hbase-master] HBASE_CONF_DIR=${HBASE_CONF_DIR:-<unset>}"
echo "[hbase-master] HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-<unset>}"

if [ ! -f "${HBASE_CONF_DIR}/hbase-site.xml" ]; then
  echo "[hbase-master] ERROR: hbase-site.xml not found in ${HBASE_CONF_DIR}"
  ls -la "${HBASE_CONF_DIR}" || true
  exit 1
fi

echo "[hbase-master] Starting HMaster..."
exec "${HBASE_HOME}/bin/hbase" master start

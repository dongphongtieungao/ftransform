#!/bin/bash

REPOSITORY=sk-hbase-226-hdfs
PROJECT=pinpoint

echo "📦 Đọc version từ _version.txt..."
version=$(cat _version.txt)
export DOCKER_BUILDKIT=0
#DOCKER_CONFIG=~/.docker-no-auth docker login azureadmin.azurecr.io --username admin --password-stdin <<< "admin"
docker login azureadmin.azurecr.io --username 'azureadmin' --password 'BXmGBeEpUyUb3M6dpYFTHkrKOH1gKKM60W9ufUgmjVLXzKv1be0oJQQJ99CBACYeBjFEqg7NAAACAZCRw0vA'

echo "🔨 Build Docker image..."
docker build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy -t azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version} .

echo "🚀 Push image versioned tag..."
docker push azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version}

echo "🔁 Tag thêm latest..."
docker tag azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version} azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:latest

echo "🚀 Push image latest tag..."
docker push azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:latest

echo "✅ Hoàn tất đẩy Docker image"
echo "===================="
echo "        Done        "
echo "===================="

# Cập nhật version tăng 0.1
k=$(awk "BEGIN {print $version+0.1; exit}")
echo $k > _version.txt

echo "Press [Enter] key to close..."
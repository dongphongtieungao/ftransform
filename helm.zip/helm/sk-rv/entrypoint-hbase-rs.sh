#!/bin/bash
set -euo pipefail

echo "[hbase-rs] HBASE_HOME=${HBASE_HOME:-<unset>}"
echo "[hbase-rs] HBASE_CONF_DIR=${HBASE_CONF_DIR:-<unset>}"
echo "[hbase-rs] HADOOP_CONF_DIR=${HADOOP_CONF_DIR:-<unset>}"

if [ ! -f "${HBASE_CONF_DIR}/hbase-site.xml" ]; then
  echo "[hbase-rs] ERROR: hbase-site.xml not found in ${HBASE_CONF_DIR}"
  ls -la "${HBASE_CONF_DIR}" || true
  exit 1
fi

echo "[hbase-rs] Starting RegionServer..."
exec "${HBASE_HOME}/bin/hbase" regionserver start


# Kiến trúc triển khai Pinpoint Stack Helm Chart

## Tổng quan

`pinpoint-stack` là một **Helm Umbrella Chart** triển khai toàn bộ stack Pinpoint 3.0.3 trên Kubernetes, bao gồm:

- **Backend Storage Layer**: HDFS + HBase 2.2.6 + ZooKeeper
- **Pinpoint Collector**: Thu thập dữ liệu từ agents
- **Pinpoint Application Stack**: Web, Batch, Flink, Kafka, Pinot, MySQL, Redis (từ subchart `pinpoint`)

## Kiến trúc phân lớp

### Layer 1: ZooKeeper (Coordination Layer)
- Service: `<release>-zookeeper` (2181)
- Replicas: PoC 1 / Prod 3
- Vai trò: coordination cho HBase/Kafka/Pinot

### Layer 2: HDFS
- NameNode: `<release>-hdfs-namenode` (RPC 8020, UI 50070)
- DataNode: `<release>-hdfs-datanode`
- Root data cho HBase:
  - `hdfs://<release>-hdfs-namenode:8020/hbase`
  - `hdfs://<release>-hdfs-namenode:8020/hbaseWALs`

### Layer 3: HBase
- Master: `<release>-hbase-master` (16010)
- RegionServer: `<release>-hbase-rs` (16030)
- Dùng ZooKeeper external: `<release>-zookeeper`

### Layer 4: Schema Init
- Job hook: `<release>-pinpoint-schema-init`
- Hook `post-install,post-upgrade`
- Tạo bảng Pinpoint trên HBase

### Layer 5: Collector
- Deployment: `<release>-collector`
- Ports: 9991/9992/9993
- Chờ `/hbase/hbaseid` trước khi start

### Layer 6: Pinpoint subchart
- Bật khi `pinpoint.enabled=true`
- Dùng backend do parent chart dựng (không deploy lại ZK/HBase/Collector nội bộ)

## Startup sequence (rút gọn)
1. ZooKeeper
2. HDFS NameNode
3. HDFS DataNode
4. HBase Master
5. HBase RegionServer
6. Schema Init Job
7. Collector
8. Pinpoint App

## Lưu ý HA hiện tại
- HDFS NameNode: chưa HA Active/Standby
- HBase Master: thường 1 replica

## Tham chiếu
- Triển khai: `helm/02_DEPLOYMENT_GUIDE.md`
- Verify nhanh: `helm/03_VERIFY_CHECKLIST_QUICK.md`
- Verify sâu: `helm/04_VERIFY_CHECKLIST_FULL.md`
- Runbook: `helm/05_RUNBOOK_OPERATIONS.md`
- Notes quan trọng: `helm/06_IMPORTANT_NOTES.md`
- Roadmap: `helm/07_NEXT_ROADMAP.md`

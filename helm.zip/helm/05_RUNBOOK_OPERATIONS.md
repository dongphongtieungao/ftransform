# Runbook — Operations

## Tham chiếu nhanh
- Deploy: `helm/02_DEPLOYMENT_GUIDE.md`
- Architecture: `helm/01_ARCHITECTURE.md`
- Quick verify: `helm/03_VERIFY_CHECKLIST_QUICK.md`
- Full verify: `helm/04_VERIFY_CHECKLIST_FULL.md`

## Biến
```powershell
$NS  = "pp-test"
$REL = "pp"
```

## 1) Kiểm tra nhanh sự cố
```powershell
kubectl -n $NS get pods -o wide
kubectl -n $NS get events --sort-by='.lastTimestamp' --field-selector type!=Normal
helm -n $NS status $REL
```

## 2) Restart theo dependency
1. ZooKeeper
2. HDFS
3. HBase
4. Collector
5. App layer

```powershell
kubectl rollout restart sts/$REL-zookeeper -n $NS
kubectl rollout restart sts/$REL-hdfs-namenode -n $NS
kubectl rollout restart sts/$REL-hdfs-datanode -n $NS
kubectl rollout restart sts/$REL-hbase-master -n $NS
kubectl rollout restart sts/$REL-hbase-rs -n $NS
kubectl rollout restart deploy/$REL-collector -n $NS
```

## 3) Playbook lỗi thường gặp
- `NoNode /hbase/hbaseid`: kiểm tra znode + restart collector sau khi backend ổn.
- `Illegal WAL directory`: xác nhận WAL dùng `/hbaseWALs`.
- HDFS chưa ready: kiểm tra `dfsadmin -report`, SafeMode, DataNode live.

## 4) Failover test cơ bản
```powershell
kubectl scale sts/$REL-hdfs-datanode -n $NS --replicas=2
kubectl scale sts/$REL-hbase-rs -n $NS --replicas=2
# scale lại bình thường sau test
```

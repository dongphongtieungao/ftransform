# Next Roadmap — HA / Optimize / Hardening

## P1 — HA bắt buộc
1. HDFS NameNode HA (Active/Standby + JournalNodes + ZKFC)
2. HBase Master HA (Active/Standby)

## P2 — Optimization
3. Resource tuning cho Web/Kafka/Pinot/MySQL/Redis
4. Storage IOPS/throughput tuning
5. Data locality / scheduling policy

## P3 — Reliability & Security
6. Hardening secrets/TLS/network ACL
7. Backup/restore drill định kỳ
8. Dashboard + alert + SLO

## DoD tổng
- Không còn SPOF control plane
- Có profile PoC/Prod rõ ràng
- Có baseline trước/sau optimize
- Có runbook & drill thực tế

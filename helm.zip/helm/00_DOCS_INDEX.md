# Pinpoint Stack Docs Index

Bộ tài liệu chuẩn (đã chuẩn hoá tên file, tránh trùng lặp vai trò):

1. `helm/01_ARCHITECTURE.md`
   - Kiến trúc triển khai, dependency, startup sequence.

2. `helm/02_DEPLOYMENT_GUIDE.md`
   - Quy trình triển khai chuẩn: Backend → Schema → Collector → App.

3. `helm/03_VERIFY_CHECKLIST_QUICK.md`
   - Checklist verify nhanh sau deploy.

4. `helm/04_VERIFY_CHECKLIST_FULL.md`
   - Checklist verify chuyên sâu (performance/ổn định).

5. `helm/05_RUNBOOK_OPERATIONS.md`
   - Runbook vận hành/sự cố/failover cơ bản.

6. `helm/06_IMPORTANT_NOTES.md`
   - Các lưu ý bắt buộc (credentials, WAL/rootdir, security, gate trước khi qua bước).

7. `helm/07_NEXT_ROADMAP.md`
   - Các việc tiếp theo: HA, optimize, hardening.

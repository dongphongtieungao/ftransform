# Verify Checklist — Quick

## Biến dùng chung
```powershell
$NS  = "pp-test"
$REL = "pp"
```

## 1) Cluster/Pods
- [ ] Node Ready
- [ ] Pod không Pending/CrashLoop
- [ ] Restart count không tăng bất thường

## 2) HDFS
- [ ] Live DataNodes đúng kỳ vọng
- [ ] Không missing/corrupt blocks
- [ ] Có `/hbase` và `/hbaseWALs`

## 3) ZooKeeper
- [ ] `ruok` = `imok`
- [ ] Có `/hbase`, `/hbase/master`, `/hbase/hbaseid`

## 4) HBase
- [ ] Không lỗi `Illegal WAL directory`
- [ ] `status 'simple'` không dead RS
- [ ] `list` thấy bảng Pinpoint

## 5) Collector
- [ ] Deployment READY đúng replica
- [ ] Không lỗi `NoNode /hbase/hbaseid`

## 6) App layer (nếu bật)
- [ ] Web/Kafka/Pinot/MySQL/Redis Running

## Tham chiếu
- Checklist sâu: `helm/04_VERIFY_CHECKLIST_FULL.md`
- Runbook: `helm/05_RUNBOOK_OPERATIONS.md`

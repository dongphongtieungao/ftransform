# Important Notes (Must Read)

## 1) Triển khai đúng thứ tự
Backend (ZK/HDFS/HBase) → Schema Init → Collector → App.

## 2) Cấu hình sống còn
- `hbase.rootdir`: `hdfs://<release>-hdfs-namenode:8020/hbase`
- `hbase.wal.dir`: `hdfs://<release>-hdfs-namenode:8020/hbaseWALs`

## 3) Credentials phải giữ ổn định qua upgrade
- Redis password
- Kafka clusterId

## 4) Gate trước khi bật Collector
- Có `/hbase/hbaseid`
- HBase `status 'simple'` không dead RS

## 5) Security khi expose Internet
- Chỉ mở khi cần
- Giới hạn IP
- Ưu tiên TLS + gateway/ingress

## 6) HA gap hiện tại
- NameNode chưa HA Active/Standby
- HBase Master chưa HA đầy đủ

## Tham chiếu
- Deploy: `helm/02_DEPLOYMENT_GUIDE.md`
- Runbook: `helm/05_RUNBOOK_OPERATIONS.md`
- Roadmap: `helm/07_NEXT_ROADMAP.md`

# Verify Checklist — Full (Deep Check)

> Checklist chuyên sâu để điều tra ổn định/performance sau deploy.

## Biến dùng chung
```powershell
$NS  = "pp-test"
$REL = "pp"
```

## 1) Cluster health
```powershell
kubectl get nodes -o wide
kubectl top nodes
kubectl -n $NS get events --sort-by='.lastTimestamp' --field-selector type!=Normal
```

## 2) Pod & restart
```powershell
kubectl -n $NS get pods -o wide --sort-by='.metadata.name'
kubectl -n $NS get pods -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{range .status.containerStatuses[*]}{.restartCount}{" "}{end}{"\n"}{end}'
```

## 3) Storage/PVC
```powershell
kubectl -n $NS get pvc -o wide
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- df -h /hadoop/dfs/name
kubectl -n $NS exec -it $REL-hdfs-datanode-0 -- df -h /hadoop/dfs/data
kubectl -n $NS exec -it $REL-hbase-rs-0 -- df -h /hbase-data
```

## 4) HDFS
```powershell
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- hdfs dfsadmin -report
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- hdfs fsck / -files -blocks
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- hdfs dfs -ls /
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- hdfs dfs -ls /hbase
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- hdfs dfs -ls /hbaseWALs
```

## 5) ZooKeeper
```powershell
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo ruok | nc localhost 2181"
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo 'ls /hbase' | zkCli.sh"
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo 'get /hbase/master' | zkCli.sh"
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo 'get /hbase/hbaseid' | zkCli.sh"
```

## 6) HBase
```powershell
kubectl -n $NS logs $REL-hbase-master-0 --tail=200
kubectl -n $NS exec -it $REL-hbase-master-0 -- bash -c "export PATH=/opt/hbase/hbase-2.2.6/bin:\$PATH; echo \"status 'simple'\" | hbase shell -n"
kubectl -n $NS exec -it $REL-hbase-master-0 -- bash -c "export PATH=/opt/hbase/hbase-2.2.6/bin:\$PATH; echo 'list' | hbase shell -n"
```

## 7) Collector
```powershell
kubectl -n $NS get deploy,pod -l app.kubernetes.io/component=collector -o wide
kubectl -n $NS get ep $REL-collector
kubectl -n $NS logs deploy/$REL-collector --tail=200
```

## 8) App layer
```powershell
kubectl -n $NS get pods -o wide
```

## Kết luận
- Nếu fail: xử lý theo `helm/05_RUNBOOK_OPERATIONS.md`
- Nếu là việc kiến trúc/tối ưu: ghi vào `helm/07_NEXT_ROADMAP.md`

# Deployment Guide — Pinpoint Stack Helm (Operational Flow + Quick Check)

Tài liệu này ưu tiên thao tác thực tế: có **clean reinstall**, **watch pod/log realtime**, và **exec check nhanh** ngay trong từng bước.

## 0) Biến dùng chung

```powershell
$NS  = "pp-test"
$REL = "pp"
cd C:\Sk\hbaseCluster
```

## 1) Clean reinstall (tuỳ chọn, dùng khi cần cài lại từ đầu)

> Cảnh báo: bước này xoá dữ liệu trong namespace PoC.

```powershell
# Gỡ release (nếu có)
helm -n $NS uninstall $REL

# Xoá PVC trong namespace
kubectl -n $NS delete pvc --all

# (Tuỳ chọn) xoá namespace để sạch hoàn toàn
kubectl delete ns $NS

# Tạo lại namespace
kubectl create ns $NS
```

### Quick check

```powershell
kubectl get ns $NS
kubectl -n $NS get pvc
helm -n $NS list
```

---

## 2) Chuẩn bị chart

```powershell
helm dependency build .\helm\pinpoint-stack
# hoặc: helm dependency update .\helm\pinpoint-stack
```

### Quick check

```powershell
helm dependency list .\helm\pinpoint-stack
```

---

## 3) Deploy backend (ZK + HDFS + HBase), chưa Collector/App

```powershell
helm install $REL ./helm/pinpoint-stack `
  -n $NS --create-namespace `
  --set collector.enabled=false `
  --set schemaInit.enabled=false `
  --set pinpoint.enabled=false `
  --wait --timeout 20m
```

### Quick check (realtime + exec)

```powershell
# Theo dõi pod realtime
kubectl -n $NS get pods -w

# Theo dõi event cảnh báo
kubectl -n $NS get events --sort-by='.lastTimestamp' --field-selector type!=Normal -w

# Kiểm tra backend đã lên
kubectl -n $NS get pods -o wide

# Exec kiểm tra nhanh HDFS
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- sh -c "hdfs dfsadmin -report | head -30"

# Exec kiểm tra nhanh ZK
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo 'ls /hbase' | zkCli.sh"

# Exec kiểm tra nhanh HBase
kubectl -n $NS exec -it $REL-hbase-master-0 -- bash -c "export PATH=/opt/hbase/hbase-2.2.6/bin:$PATH; echo \"status 'simple'\" | hbase shell -n"
```

---

## 4) Bật schema init

```powershell
helm upgrade $REL ./helm/pinpoint-stack `
  -n $NS `
  --set schemaInit.enabled=true `
  --set collector.enabled=false `
  --set pinpoint.enabled=false `
  --wait --timeout 20m
```

### Quick check (realtime + exec)

```powershell
# Theo dõi job
kubectl -n $NS get jobs -w

# Theo dõi log schema realtime
kubectl -n $NS logs job/$REL-pinpoint-schema-init -f

# Verify bảng HBase đã tạo
kubectl -n $NS exec -it $REL-hbase-master-0 -- bash -c "export PATH=/opt/hbase/hbase-2.2.6/bin:$PATH; echo 'list' | hbase shell -n"

# Verify dữ liệu trên HDFS
kubectl -n $NS exec -it $REL-hdfs-namenode-0 -- sh -c "hdfs dfs -ls /hbase/data/default"
```

Sau khi schema OK, tắt lại schema hook:

```powershell
helm upgrade $REL ./helm/pinpoint-stack -n $NS `
  --set schemaInit.enabled=false `
  --set collector.enabled=false `
  --set pinpoint.enabled=false
```

---

## 5) Bật Collector

```powershell
helm upgrade $REL ./helm/pinpoint-stack `
  -n $NS `
  --set schemaInit.enabled=false `
  --set collector.enabled=true `
  --set pinpoint.enabled=false `
  --wait --timeout 20m
```

### Quick check (realtime + exec)

```powershell
# Theo dõi collector pod realtime
kubectl -n $NS get pods -l app.kubernetes.io/component=collector -w

# Theo dõi collector log realtime
kubectl -n $NS logs deploy/$REL-collector -f

# Kiểm tra endpoint
kubectl -n $NS get ep $REL-collector

# Kiểm tra znode bắt buộc cho collector
kubectl -n $NS exec -it $REL-zookeeper-0 -- sh -c "echo 'get /hbase/hbaseid' | zkCli.sh"
```

---

## 6) Bật Pinpoint app layer

```powershell
$REDIS_PASSWORD = "StrongRedis!123"
$CLUSTER_ID = "<cluster-id>"

helm upgrade $REL .\helm\pinpoint-stack `
  -n $NS `
  --set schemaInit.enabled=false `
  --set collector.enabled=true `
  --set pinpoint.enabled=true `
  --set pinpoint.global.metric.enabled=true `
  --set pinpoint.redis.auth.password="$REDIS_PASSWORD" `
  --set pinpoint.kafka.clusterId="$CLUSTER_ID" `
  --wait --timeout 30m
```

### Quick check (realtime + log)

```powershell
# Theo dõi toàn bộ pod realtime
kubectl -n $NS get pods -w

# Theo dõi web log
kubectl -n $NS logs -l app.kubernetes.io/component=web --tail=100 -f

# Theo dõi kafka (nếu bật metric profile)
kubectl -n $NS logs -l app.kubernetes.io/name=kafka --tail=100 -f

# Theo dõi pinot (nếu bật metric profile)
kubectl -n $NS logs -l app=pinot --tail=100 -f
```

---

## 7) Bộ lệnh theo dõi nhanh dùng lại mọi bước

```powershell
# Pod realtime
kubectl -n $NS get pods -w

# Event warning realtime
kubectl -n $NS get events --sort-by='.lastTimestamp' --field-selector type!=Normal -w

# Log realtime theo component
kubectl -n $NS logs deploy/$REL-collector -f
kubectl -n $NS logs -l app.kubernetes.io/component=web -f

# Tổng quan tài nguyên
kubectl -n $NS get pods -o wide
kubectl -n $NS get svc
kubectl -n $NS get pvc
helm -n $NS status $REL
```

---

## 8) Rollback

```powershell
helm history $REL -n $NS
helm rollback $REL <revision> -n $NS
```

Quick check sau rollback:

```powershell
helm -n $NS status $REL
kubectl -n $NS get pods -o wide
```

---

## Tham chiếu
- Kiến trúc: `helm/01_ARCHITECTURE.md`
- Verify nhanh: `helm/03_VERIFY_CHECKLIST_QUICK.md`
- Verify sâu: `helm/04_VERIFY_CHECKLIST_FULL.md`
- Runbook vận hành: `helm/05_RUNBOOK_OPERATIONS.md`
- Notes quan trọng: `helm/06_IMPORTANT_NOTES.md`
- Roadmap: `helm/07_NEXT_ROADMAP.md`
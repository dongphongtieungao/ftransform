#!/bin/bash

REPOSITORY=sk-hdfs-namenode
PROJECT=pinpoint

# Thư mục script: c:/Sk/hbaseCluster/helm/namenode
# _version.txt dùng chung ở thư mục helm (cha)
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="${BASE_DIR%/namenode}"

VERSION_FILE="$ROOT_DIR/_version.txt"

echo "📦 Đọc version từ $VERSION_FILE..."
version=$(cat "$VERSION_FILE")
export DOCKER_BUILDKIT=0

# Đăng nhập ACR (giữ nguyên như script gốc nếu bạn đang dùng)
docker login azureadmin.azurecr.io --username 'azureadmin' --password 'BXmGBeEpUyUb3M6dpYFTHkrKOH1gKKM60W9ufUgmjVLXzKv1be0oJQQJ99CBACYeBjFEqg7NAAACAZCRw0vA'

echo "🔨 Build Docker image sk-hdfs-namenode..."
cd "$BASE_DIR"
docker build --build-arg http_proxy=$http_proxy --build-arg https_proxy=$https_proxy -t azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version} .

echo "🚀 Push image versioned tag..."
docker push azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version}

echo "🔁 Tag thêm latest..."
docker tag azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:${version} azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:latest

echo "🚀 Push image latest tag..."
docker push azureadmin.azurecr.io/${PROJECT}/${REPOSITORY}:latest

echo "✅ Hoàn tất đẩy Docker image sk-hdfs-namenode"
echo "===================="
echo "        Done        "
echo "===================="

# Cập nhật version tăng 0.1 (dùng chung với _version.txt ở helm)
k=$(awk "BEGIN {print $version+0.1; exit}")
echo $k > "$VERSION_FILE"

echo "Press [Enter] key to close..."
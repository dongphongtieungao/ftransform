**test strategy cho một ứng dụng Helm chart**

# 1. Mục tiêu test Helm chart

Xác nhận các đặc tính:

1. Render đúng manifest theo values
2. Deploy thành công trên cluster chuẩn
3. Hoạt động đúng khi runtime
4. Upgrade không downtime ngoài SLA
5. Rollback an toàn
6. Tương thích multi environment
7. Idempotent
8. Không phá resource đang tồn tại

---

# 2. Test tĩnh (Static / Lint / Template)

## 2.1 Helm lint

Kiểm tra:

* Chart.yaml hợp lệ
* values.yaml schema
* dependency đúng version

```bash
helm lint
```

### Ý tưởng test

Test matrix:

* values mặc định
* values production
* values minimal
* values bật tắt feature flag

---

## 2.2 Render template

```bash
helm template
```

So sánh với snapshot đã approve.

### Kiểm tra

* image tag đúng
* resource limit/requests
* affinity / toleration
* storage class
* serviceAccount
* securityContext

Có thể dùng:

* helm-unittest
* chart-testing
* kubeconform / kubeval

---

## 2.3 Schema validation

Nếu có `values.schema.json`

Test:

* truyền sai kiểu dữ liệu
* thiếu field bắt buộc
* field ngoài schema

---

# 3. Test cài đặt (Install test)

## 3.1 Install clean

```bash
helm install
```

Xác nhận:

* Pod Running
* PVC Bound
* Service có endpoint
* Job init chạy xong

---

## 3.2 Install lại cùng release name

Test tính idempotent:

```bash
helm install → uninstall → install lại
```

---

## 3.3 Install song song nhiều release

Test:

* namespace isolation
* fullnameOverride
* name collision

---

# 4. Test runtime

## 4.1 Health check

Kiểm tra:

* readinessProbe
* livenessProbe

Test scenario:

* Pod restart → có recover không
* Kill container → có recreate không

---

## 4.2 Config change

Update ConfigMap / Secret qua Helm:

```bash
helm upgrade
```

Xác nhận:

* rollout đúng
* không downtime ngoài dự kiến
* checksum annotation hoạt động

---

## 4.3 Persistence test

Với workload stateful:

* restart pod → data còn
* scale up → data đúng shard
* scale down → không mất data

---

# 5. Test upgrade

## 5.1 Upgrade version

Test:

```bash
helm upgrade v1 → v2
```

Kiểm tra:

* migration job
* CRD compatibility
* PVC reuse
* schema change

---

## 5.2 Backward compatibility của values

Values cũ vẫn chạy được.

---

# 6. Test rollback

```bash
helm rollback
```

Kiểm tra:

* workload recover
* data không corrupt
* service hoạt động lại

---

# 7. Test scaling

## 7.1 Scale bằng values

```yaml
replicaCount: 3
```

Test:

* HPA tương thích
* anti-affinity hoạt động
* topology spread

---

## 7.2 Load test

Xác nhận:

* autoscaling trigger
* resource allocation đúng

---

# 8. Test multi environment

Matrix:

| Environment | Test              |
| ----------- | ----------------- |
| dev         | minimal resource  |
| staging     | production config |
| prod        | HA                |

---

# 9. Test failure scenario

### 9.1 Thiếu dependency

Ví dụ:

* thiếu storage class
* thiếu CRD

Chart phải:

* fail fast
* message rõ ràng

---

### 9.2 Node failure

Drain node:

```bash
kubectl drain
```

Kiểm tra:

* reschedule đúng
* PDB hoạt động

---

### 9.3 Storage chậm

Xác nhận:

* startup timeout
* probe không fail giả

---

# 10. Test security

Kiểm tra:

* runAsNonRoot
* readOnlyRootFilesystem
* không dùng latest tag
* RBAC tối thiểu

---

# 11. Test CI/CD automation

Pipeline đề xuất:

### Stage 1

* helm lint
* helm template
* schema validate

### Stage 2

Spin up:

* kind / k3d

Run:

* helm install
* helm test

### Stage 3

Upgrade test.

---

# 12. Test bằng helm test

Viết test pod:

Ví dụ:

* test connect DB
* test HTTP endpoint
* test Kafka topic

---

# 13. Non functional test

## 13.1 Performance

* thời gian install
* thời gian upgrade
* thời gian scale

## 13.2 Reliability

Test loop:

```bash
install → upgrade → rollback → uninstall
```

N lần.

---

# 14. DR test

Test:

* backup PVC
* restore sang cluster mới
* deploy chart → attach lại data

---

# 15. Output cần thu được

Bộ artifact:

* test matrix
* checklist pass/fail
* SLA upgrade
* supported values matrix

---

# 16. Nếu áp vào hệ thống bạn đang làm

Với các workload kiểu:

* HBase
* Airflow
* Pinpoint
* Kafka

Cần bổ sung test:

* StatefulSet ordinal
* WAL durability
* region reassign
* job recovery

---

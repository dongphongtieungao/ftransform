import pytest
import time
from .test_harness import (
    helm, kubectl, wait_for_pods_ready, write_artifact, 
    find_first_pod_name, exec_in_pod, apply_patch_values, CommandError
)

class TestPinpointStackAuto:
    """Automation mapping for manual test plan in `test/test_plan_detail.md`.

    Mapping overview:
    - Suite A (section 2): Preflight
      - TC A01 → test_a01_helm_lint
      - TC A02 → test_a02_helm_template_check
    - Suite B (section 3): Install & Smoke
      - TC B01 → test_b01_prepare_namespace
      - TC B02 → test_b02_helm_install
      - TC B03 → test_b03_verify_pods_ready
      - TC B04 → test_b04_verify_pvc_bound
    - Suite C (section 4): HBase functional
      - TC C01 → test_c01_hbase_basic_rw
    - Suite E (section 6): Upgrade & Rollback
      - TC E01 → test_e01_upgrade_safe
      - TC E02 → test_e02_rollback

    Suites D, F, G hiện chưa có automation → thực hiện manual theo `test/test_plan_detail.md`.
    """

    # --- Suite A: Preflight ---
    
    def test_a01_helm_lint(self, cfg):
        """TC A01 (Suite A / §2): Helm lint chart."""
        out = helm(cfg, ["lint", cfg.chart])
        write_artifact(cfg, "suite_a_lint.txt", out)
        assert "0 chart(s) failed" in out

    def test_a02_helm_template_check(self, cfg):
        """TC A02 (Suite A / §2): Render manifest và kiểm tra image/PVC/selector."""
        out = helm(cfg, ["template", cfg.release, cfg.chart, "-n", cfg.namespace, "-f", cfg.values])
        write_artifact(cfg, "suite_a_render.yaml", out)
        
        # Check for latest tags (should not exist in production-ready charts)
        # Note: In this specific repo, some images might use 'latest', we check and log.
        latest_counts = out.count(":latest")
        if latest_counts > 0:
            print(f"Warning: Found {latest_counts} ':latest' image tags")
        
        # Chart này dùng volumeClaimTemplates trong StatefulSet chứ không tạo PVC rời.
        # Để bám đúng test plan (kiểm PVC/storage), ta kiểm tra sự hiện diện của volumeClaimTemplates
        # và label app ổn định.
        assert "volumeClaimTemplates:" in out, "Rendered manifest does not define any volumeClaimTemplates for PVCs"
        assert "app.kubernetes.io/name: pinpoint-stack" in out, "Rendered manifest missing expected app label"

    # --- Suite B: Install & Smoke ---

    def test_b01_prepare_namespace(self, cfg):
        """TC B01 (Suite B / §3): Tạo namespace sạch (idempotent)."""
        try:
            kubectl(cfg, ["create", "ns", cfg.namespace])
        except CommandError:
            print(f"Namespace {cfg.namespace} already exists")

    def test_b02_helm_install(self, cfg):
        """TC B02 (Suite B / §3): Helm install chart (install clean)."""
        # Trước khi install, cố gắng uninstall release cũ (nếu có) để tránh lỗi "name is still in use"
        try:
            print(f"[DEBUG] Attempting pre-clean uninstall of release {cfg.release} in ns {cfg.namespace}")
            helm(cfg, ["uninstall", cfg.release, "-n", cfg.namespace])
        except CommandError as e:
            print(f"[DEBUG] Pre-clean uninstall skipped/failed (can be OK if release not found): {e}")

        # Use --wait to let helm handle basic readiness
        out = helm(cfg, [
            "install", cfg.release, cfg.chart,
            "-n", cfg.namespace,
            "-f", cfg.values,
            "--wait", "--timeout", "15m",
        ])
        write_artifact(cfg, "suite_b_install.txt", out)
        assert "STATUS: deployed" in out

    def test_b03_verify_pods_ready(self, cfg):
        """TC B03 (Suite B / §3): Kiểm tra trạng thái Ready của các Pod."""
        components = [
            "zookeeper", "hdfs-namenode", "hdfs-datanode",
            "hbase-master", "hbase-rs", "collector",
        ]
        for comp in components:
            selector = f"app.kubernetes.io/component={comp}"
            wait_for_pods_ready(cfg, selector=selector, min_ready=1)

    def test_b04_verify_pvc_bound(self, cfg):
        """TC B04 (Suite B / §3): Kiểm tra trạng thái Bound của PVC."""
        out = kubectl(
            cfg,
            [
                "get",
                "pvc",
                "-n",
                cfg.namespace,
                "-o",
                "jsonpath={.items[*].status.phase}",
            ],
        )
        phases = out.split()
        assert all(p == "Bound" for p in phases), f"Some PVCs are not Bound: {out}"

    # --- Suite C: HBase Functional ---

    def test_c01_hbase_basic_rw(self, cfg):
        """TC C01 (Suite C / §4): Kiểm tra HBase đọc ghi cơ bản via hbase shell."""
        master_pod = find_first_pod_name(cfg, "app.kubernetes.io/component=hbase-master")

        test_commands = [
            "create 'autotest_table', 'cf'",
            "put 'autotest_table', 'row1', 'cf:q1', 'val1'",
            "get 'autotest_table', 'row1'",
            "disable 'autotest_table'",
            "drop 'autotest_table'",
        ]

        cmd_str = "\n".join(test_commands)

        # Dùng HBASE_HOME/bin/hbase để tránh phụ thuộc PATH trong container
        hbase_shell_cmd = (
            "set -e; "
            "echo '=== which hbase (PATH) ==='; which hbase || echo 'hbase not in PATH'; "
            "echo '=== env | grep -i HBASE ==='; env | grep -i HBASE || true; "
            "echo '=== running hbase shell via $HBASE_HOME/bin/hbase ==='; "
            f"echo \"{cmd_str}\" | \"$HBASE_HOME/bin/hbase\" shell -n"
        )

        # Thử nhiều lần vì HBase có thể chưa kịp đăng ký /hbase/master trong ZooKeeper.
        last_out = ""
        max_attempts = 3
        for attempt in range(max_attempts):
            print(f"[DEBUG] HBase shell attempt {attempt+1}/{max_attempts} on pod {master_pod}")
            try:
                last_out = exec_in_pod(
                    cfg,
                    master_pod,
                    ["/bin/sh", "-c", hbase_shell_cmd],
                )
                break
            except CommandError as e:
                msg = (e.stdout or "") + "\n" + (e.stderr or "")
                if "KeeperErrorCode = NoNode for /hbase/master" in msg and attempt < max_attempts - 1:
                    print("[DEBUG] HBase znode /hbase/master chưa sẵn sàng, sleep 10s rồi thử lại")
                    time.sleep(10)
                    continue
                raise

        out = last_out
        write_artifact(cfg, "suite_c_hbase_test.txt", out)

        # Kỳ vọng có row đã put, và table được drop thành công
        assert "0 row(s)" not in out
        assert "DROP TABLE" in out or "autotest_table" not in out

    # --- Suite E: Upgrade/Rollback ---

    def test_e01_upgrade_safe(self, cfg):
        """TC E01 (Suite E / §6): Upgrade thay đổi nhỏ và xác nhận."""
        patch_file = apply_patch_values(cfg)
        out = helm(
            cfg,
            [
                "upgrade",
                cfg.release,
                cfg.chart,
                "-n",
                cfg.namespace,
                "-f",
                cfg.values,
                "-f",
                str(patch_file),
                "--wait",
            ],
        )
        write_artifact(cfg, "suite_e_upgrade.txt", out)
        # Helm upgrade output không luôn in STATUS, nhưng luôn có thông điệp "has been upgraded"
        assert ("STATUS: deployed" in out) or ("has been upgraded" in out), \
            "Helm upgrade did not report successful deployment"

        # Verify collector replicas scaled (based on patch-values.yaml)
        replicas = kubectl(
            cfg,
            [
                "get",
                "deploy",
                "-n",
                cfg.namespace,
                "-l",
                "app.kubernetes.io/component=collector",
                "-o",
                "jsonpath={.items[0].spec.replicas}",
            ],
        )
        assert replicas == "2"

    def test_e02_rollback(self, cfg):
        """TC E02 (Suite E / §6): Rollback và xác nhận hồi phục."""
        # Rollback to revision 1 (the initial install)
        out = helm(cfg, ["rollback", cfg.release, "1", "-n", cfg.namespace, "--wait"])
        write_artifact(cfg, "suite_e_rollback.txt", out)

        # Verify collector replicas back to 3 (original values.yaml)
        replicas = kubectl(
            cfg,
            [
                "get",
                "deploy",
                "-n",
                cfg.namespace,
                "-l",
                "app.kubernetes.io/component=collector",
                "-o",
                "jsonpath={.items[0].spec.replicas}",
            ],
        )
        assert replicas == "3"

"""Shared harness helpers for Pinpoint Stack manual test-plan automation.

This module intentionally uses subprocess for Helm/Kubectl to stay close to
how the stack is operated (manual plan uses helm + kubectl).
"""

from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


class CommandError(RuntimeError):
    def __init__(self, cmd: list[str], returncode: int, stdout: str, stderr: str):
        super().__init__(f"Command failed ({returncode}): {' '.join(cmd)}\n{stderr}")
        self.cmd = cmd
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


@dataclass(frozen=True)
class TestConfig:
    namespace: str
    release: str
    chart: str
    values: str
    artifacts_dir: Path

    @property
    def fullname_prefix(self) -> str:
        # chart fullname is chart name unless fullnameOverride is set.
        # In this repo chart name is "pinpoint-stack".
        # Resource names use: <fullname>-<component>, where fullname==chart name.
        return "pinpoint-stack"


def env(name: str, default: str) -> str:
    v = os.getenv(name)
    return v if v not in (None, "") else default


def run_cmd(
    cmd: list[str],
    *,
    cwd: Optional[str] = None,
    timeout_s: Optional[int] = None,
    capture: bool = True,
) -> subprocess.CompletedProcess[str]:
    p = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        encoding="utf-8",
        errors="replace",
        capture_output=capture,
        timeout=timeout_s,
        check=False,
    )
    if p.returncode != 0:
        # Detailed debug to help diagnose Helm/kubectl issues on Windows
        debug = [
            "[DEBUG] Command failed",
            f"  CMD : {' '.join(cmd)}",
            f"  CWD : {cwd or os.getcwd()}",
            f"  RC  : {p.returncode}",
            "  STDOUT:",
            (p.stdout or "").rstrip(),
            "  STDERR:",
            (p.stderr or "").rstrip(),
        ]
        print("\n".join(debug))
        raise CommandError(cmd, p.returncode, p.stdout or "", p.stderr or "")
    else:
        # Lightweight success trace (can be commented out if too noisy)
        print(f"[DEBUG] OK: {' '.join(cmd)} (rc=0)")
    return p


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def write_artifact(cfg: TestConfig, name: str, content: str) -> Path:
    ensure_dir(cfg.artifacts_dir)
    path = cfg.artifacts_dir / name
    path.write_text(content, encoding="utf-8")
    return path


def helm(cfg: TestConfig, args: list[str], *, timeout_s: Optional[int] = None) -> str:
    cmd = ["helm", *args]
    out = run_cmd(cmd, timeout_s=timeout_s).stdout or ""
    return out


def kubectl(cfg: TestConfig, args: list[str], *, timeout_s: Optional[int] = None) -> str:
    cmd = ["kubectl", *args]
    out = run_cmd(cmd, timeout_s=timeout_s).stdout or ""
    return out


def wait_for_pods_ready(
    cfg: TestConfig,
    *,
    selector: str,
    timeout_s: int = 1800,
    min_ready: int = 1,
) -> None:
    """Wait until at least min_ready pods matching selector are Ready."""

    deadline = time.time() + timeout_s

    while True:
        if time.time() > deadline:
            raise TimeoutError(f"Timeout waiting for pods Ready: selector={selector}")

        out = kubectl(
            cfg,
            [
                "get",
                "pod",
                "-n",
                cfg.namespace,
                "-l",
                selector,
                "-o",
                "jsonpath={range .items[*]}{.metadata.name} {.status.containerStatuses[*].ready}{'\\n'}{end}",
            ],
        )
        lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
        ready_count = 0
        for ln in lines:
            # Example: "pod-0 true true" => all containers ready
            parts = ln.split()
            if len(parts) < 2:
                continue
            statuses = parts[1:]
            if statuses and all(s.lower() == "true" for s in statuses):
                ready_count += 1

        if ready_count >= min_ready:
            return

        time.sleep(5)


def find_first_pod_name(cfg: TestConfig, selector: str) -> str:
    out = kubectl(
        cfg,
        [
            "get",
            "pod",
            "-n",
            cfg.namespace,
            "-l",
            selector,
            "-o",
            "jsonpath={.items[0].metadata.name}",
        ],
    ).strip()
    if not out:
        raise RuntimeError(f"No pod found for selector={selector}")
    return out


def exec_in_pod(cfg: TestConfig, pod: str, command: list[str], *, timeout_s: int = 300) -> str:
    out = kubectl(
        cfg,
        ["exec", "-n", cfg.namespace, pod, "--", *command],
        timeout_s=timeout_s,
    )
    return out


def apply_patch_values(cfg: TestConfig) -> Path:
    """Create a minimal patch values file for upgrade tests."""
    ensure_dir(cfg.artifacts_dir)
    p = cfg.artifacts_dir / "patch-values.yaml"
    # Change collector replica count as a safe, non-destructive upgrade.
    p.write_text("collector:\n  replicaCount: 2\n", encoding="utf-8")
    return p

from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Dict

import pytest

from .test_harness import TestConfig, env


@pytest.fixture(scope="session")
def cfg(tmp_path_factory: pytest.TempPathFactory) -> TestConfig:
    namespace = env("NS", "pp-test")
    release = env("REL", "pp")
    chart = env("CHART", r"C:\\Sk\\hbaseCluster\\helm\\pinpoint-stack")
    values = env("VALUES", r"C:\\Sk\\hbaseCluster\\helm\\pinpoint-stack\\values.yaml")

    ts = _dt.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    base = Path(env("ARTIFACTS_DIR", str(tmp_path_factory.mktemp("artifacts"))))
    artifacts_dir = base / f"pinpoint_stack_{ts}"

    return TestConfig(
        namespace=namespace,
        release=release,
        chart=chart,
        values=values,
        artifacts_dir=artifacts_dir,
    )


# --- Simple TestCase → Result summary (for human-friendly console output) ---

_TC_LABELS: Dict[str, str] = {
    "test_a01_helm_lint": "TC A01 - Helm lint chart",
    "test_a02_helm_template_check": "TC A02 - Render manifest & kiểm tra image/PVC/selector",
    "test_b01_prepare_namespace": "TC B01 - Tạo namespace sạch",
    "test_b02_helm_install": "TC B02 - Helm install clean (install mới release)",
    "test_b03_verify_pods_ready": "TC B03 - Kiểm tra trạng thái Ready của các Pod",
    "test_b04_verify_pvc_bound": "TC B04 - Kiểm tra PVC Bound & StorageClass",
    "test_c01_hbase_basic_rw": "TC C01 - HBase basic read/write via hbase shell",
    "test_e01_upgrade_safe": "TC E01 - Upgrade nhỏ, xác nhận collector scale & không phá PVC",
    "test_e02_rollback": "TC E02 - Rollback, collector replicas về trạng thái ban đầu",
}

_TC_RESULTS: Dict[str, str] = {label: "NotRun" for label in _TC_LABELS.values()}


def pytest_runtest_makereport(item: pytest.Item, call: pytest.CallInfo) -> None:
    """Collect per-test Pass/Fail status for summary printing at the end."""
    if call.when != "call":
        return

    label = _TC_LABELS.get(item.name)
    if not label:
        return

    status = "Pass" if call.excinfo is None else "Fail"
    _TC_RESULTS[label] = status


@pytest.fixture(scope="session", autouse=True)
def _print_tc_summary(request: pytest.FixtureRequest) -> None:
    """Autouse session fixture that prints a compact TC summary after all tests."""

    def _finalizer() -> None:
        print("\n=== Test Case Summary (Pinpoint Stack) ===")
        # In order of test code names (A → B → C → E)
        for test_name in sorted(_TC_LABELS.keys()):
            label = _TC_LABELS[test_name]
            result = _TC_RESULTS.get(label, "NotRun")
            print(f"{label}: {result}")

    request.addfinalizer(_finalizer)

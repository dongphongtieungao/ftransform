"""Automation test package for Pinpoint stack.

This file makes the `automation` directory a Python package so that
relative imports like `.test_harness` in `conftest.py` work correctly
when running pytest from `C:\\Sk\\hbaseCluster\\test`.
"""


*** Test viewpoint cho helm app Pinpoint 3.0 triển khai trên Kubernetes, HBase dùng HDFS làm backend storage***

# 1. Quan điểm 1: Helm chart phải đúng về mặt khai báo và có tính quyết định

Mục tiêu là cùng một phiên bản chart và cùng một values thì luôn render ra manifest nhất quán, không phụ thuộc môi trường chạy lệnh.

## Test case phù hợp

1.1 Render snapshot theo bộ values chuẩn
Đầu vào: values-dev, values-stg, values-prod
Bước: helm template từng bộ values, lưu output, so sánh với snapshot đã duyệt
Kỳ vọng: không có thay đổi ngoài dự kiến, mọi thay đổi phải có PR và review

1.2 Lint và validate schema values
Đầu vào: values với sai kiểu dữ liệu, thiếu trường bắt buộc, dư trường không cho phép
Bước: helm lint, validate theo values.schema.json (nếu có)
Kỳ vọng: fail fast, thông báo lỗi rõ field nào sai

1.3 Tính quyết định của fullname, label, selector
Bước: render manifest, kiểm tra selector của Service, StatefulSet, Deployment, PDB
Kỳ vọng: selector ổn định, không thay đổi theo minor changes không liên quan, tránh làm “mất” endpoint khi upgrade

1.4 Dependency chart và version pin
Bước: kiểm tra Chart.lock, dependency version cố định, không pull “latest”
Kỳ vọng: build reproducible, không trôi version dependency

---

# 2. Quan điểm 2: Cài đặt sạch phải thành công và hoàn tất bootstrap đúng thứ tự

Trong Pinpoint, rủi ro thường nằm ở thứ tự các thành phần lên, migration, init job và kết nối phụ thuộc (Pinpoint components, HBase, HDFS).

## Test case phù hợp

2.1 Install clean trên namespace trống
Bước: tạo namespace mới, helm install với values tối thiểu hợp lệ
Kỳ vọng: toàn bộ Pod Ready theo ngưỡng thời gian chuẩn của bạn, Job init hoàn thành, không CrashLoopBackOff

2.2 Kiểm tra thứ tự khởi tạo phụ thuộc
Bước: quan sát initContainers, startupProbe, readinessProbe, các dependency check (ví dụ HBase trước, Pinpoint sau hoặc ngược lại tùy thiết kế)
Kỳ vọng: không có tình trạng service phụ thuộc chưa sẵn sàng nhưng workload chính đã nhận traffic

2.3 Install khi thiếu điều kiện nền tảng
Đầu vào: thiếu StorageClass, thiếu permission tạo PV, thiếu Secret cấu hình HDFS
Bước: helm install
Kỳ vọng: chart fail sớm và rõ, không tạo tài nguyên “nửa vời” khó dọn

2.4 Idempotency của cài đặt
Bước: install, uninstall, install lại cùng release name, cũng thử install song song 2 release khác nhau
Kỳ vọng: không đụng độ tên, không tái sử dụng nhầm PVC, không để lại resource rác

---

# 3. Quan điểm 3: Tính đúng đắn của cấu hình HBase trên HDFS là trung tâm

Vì HBase chạy trên HDFS, lỗi thường không lộ ngay ở install mà lộ ở runtime: quyền HDFS, path, HA NameNode, block size, replication factor, WAL, tmp.

## Test case phù hợp

3.1 HBase tạo schema trên HDFS đúng vị trí
Bước: sau khi cluster lên, kiểm tra HDFS path của hbase.rootdir và các thư mục hệ thống liên quan
Kỳ vọng: thư mục tạo được, owner và permission đúng, không có lỗi AccessControl

3.2 Test quyền ghi WAL và durability
Bước: ghi dữ liệu mẫu, theo dõi log regionserver, đảm bảo WAL append không lỗi, đảm bảo flush/compaction không lỗi
Kỳ vọng: không xuất hiện lỗi liên quan HDFS client, no lease issues, không stuck sync

3.3 Test restart RegionServer không mất dữ liệu
Bước: ghi dữ liệu, xóa pod RegionServer, chờ pod lên lại, đọc lại dữ liệu
Kỳ vọng: dữ liệu còn, region assignment hồi phục

3.4 Test hành vi khi HDFS tạm thời lỗi
Bước: tạo lỗi mạng giả lập từ HBase pod tới HDFS endpoint (bằng network policy hoặc tạm chặn route trong môi trường test)
Kỳ vọng: hệ thống báo lỗi đúng, không corrupt dữ liệu, khi kết nối lại thì tự hồi phục theo cơ chế HBase

3.5 Test HA NameNode và failover
Điều kiện: nếu bạn dùng HDFS HA
Bước: ép failover NameNode, quan sát HBase client retry
Kỳ vọng: downtime trong giới hạn bạn đặt ra, không cần can thiệp tay để HBase trở lại

---

# 4. Quan điểm 4: Pinpoint data path phải đúng, đủ và đo được

Pinpoint là hệ quan sát, nên kiểm chứng bằng “dữ liệu đi vào và hiển thị đúng” là quan trọng hơn chỉ Pod Ready.

## Test case phù hợp

4.1 Smoke test ingest end to end
Bước: gửi sample agent data hoặc traffic giả lập vào collector, kiểm tra dữ liệu xuất hiện trên UI theo thời gian
Kỳ vọng: có trace, metric, agent list, timeline đúng

4.2 Backpressure và queue behavior
Bước: tăng load ingest đột ngột, quan sát collector, broker queue, HBase write latency
Kỳ vọng: không mất dữ liệu vượt ngưỡng cho phép, hệ thống backpressure đúng cách thay vì crash

4.3 Consistency check giữa component
Bước: tắt một thành phần trung gian (ví dụ collector hoặc một node trong cluster) trong lúc ingest
Kỳ vọng: hệ thống degrade có kiểm soát, khi hồi phục thì dữ liệu tiếp tục chảy, không tạo “lỗ hổng” khó truy vết

---

# 5. Quan điểm 5: Upgrade, rollback phải an toàn và không phá dữ liệu HBase

Đây là rủi ro cao nhất khi vận hành Helm với stateful workload.

## Test case phù hợp

5.1 Upgrade minor chart version không thay PVC semantics
Bước: helm upgrade thay đổi cấu hình nhẹ, không đổi storage, không đổi name
Kỳ vọng: PVC vẫn giữ, Pod rollout theo chiến lược đã định, không recreate volume

5.2 Upgrade có thay đổi config HBase hoặc Pinpoint
Bước: thay đổi ConfigMap, Secret, image tag
Kỳ vọng: checksum annotation khiến pod restart đúng, không treo ở terminating, không split brain

5.3 Rollback sau upgrade lỗi
Bước: cố ý đưa một cấu hình sai, upgrade để fail, sau đó helm rollback
Kỳ vọng: rollback đưa hệ thống trở lại trạng thái chạy, dữ liệu không hỏng, endpoint ổn định

5.4 Test migration job (nếu có)
Bước: chạy upgrade có migration, sau đó rollback
Kỳ vọng: migration phải có cơ chế an toàn, rollback không làm trạng thái dữ liệu “nửa vời”

---

# 6. Quan điểm 6: Resilience trên Kubernetes, node chết, pod chết, zone failure

Pinpoint và HBase đều nhạy với scheduling, anti affinity, PDB, topology spread.

## Test case phù hợp

6.1 Node drain
Bước: drain một node đang chạy RegionServer hoặc thành phần Pinpoint chính
Kỳ vọng: pod được reschedule, hệ thống vẫn phục vụ, downtime nằm trong SLO

6.2 PodDisruptionBudget hoạt động đúng
Bước: thực hiện thao tác gây disruption hàng loạt (upgrade, drain, rolling)
Kỳ vọng: PDB chặn phá vỡ quá mức, không làm cluster mất quorum theo logic thiết kế

6.3 Topology spread và anti affinity
Bước: scale lên, kiểm tra pod phân bố
Kỳ vọng: không dồn hết vào một node, không tạo hotspot

6.4 Chaos test chọn lọc
Bước: kill ngẫu nhiên 1 pod mỗi nhóm quan trọng theo chu kỳ
Kỳ vọng: tự hồi phục, không memory leak, không tăng latency kéo dài

---

# 7. Quan điểm 7: Performance và storage economics, vì HDFS trên Kubernetes rất nhạy IOPS

Bạn đã nêu lo ngại về chi phí IOPS khi đưa HDFS lên k8s. Quan điểm test ở đây là “đo và chứng minh” bằng số liệu.

## Test case phù hợp

7.1 Baseline latency HBase read/write
Bước: chạy workload chuẩn, đo p95, p99 latency của write, read, scan
Kỳ vọng: đạt ngưỡng NFR bạn đặt ra

7.2 So sánh theo loại PV và StorageClass
Bước: chạy cùng workload trên các StorageClass khác nhau
Kỳ vọng: thấy rõ trade off chi phí và hiệu năng, có số liệu để quyết định

7.3 Stress compaction và WAL
Bước: tạo dữ liệu lớn để ép compaction, theo dõi IO và latency
Kỳ vọng: không vượt mức timeout, không làm Pinpoint ingest sập dây chuyền

7.4 Thử nghiệm saturation IOPS
Bước: tăng load đến khi latency tăng đột biến, ghi lại điểm gãy
Kỳ vọng: xác định capacity limit theo IOPS để lập sizing

---

# 8. Quan điểm 8: Security, RBAC, secret hygiene và hardening

Đây là rủi ro enterprise bắt buộc, đặc biệt với hệ thống observability.

## Test case phù hợp

8.1 RBAC tối thiểu
Bước: chạy với serviceAccount riêng, giới hạn permission
Kỳ vọng: vẫn hoạt động, không cần cluster-admin

8.2 Pod security context
Bước: bật runAsNonRoot, drop capabilities, readOnlyRootFilesystem nếu có thể
Kỳ vọng: container vẫn chạy, không ghi bừa vào filesystem

8.3 Secret rotation
Bước: thay secret HDFS credential hoặc auth (nếu có), helm upgrade
Kỳ vọng: component reload đúng cách, không lộ secret qua log

---

# 9. Quan điểm 9: Observability của chính hệ thống Pinpoint và HBase

Một hệ quan sát mà tự nó không quan sát được là rủi ro vận hành.

## Test case phù hợp

9.1 Metrics và log chuẩn hóa
Bước: kiểm tra metrics endpoint, log format, correlation id
Kỳ vọng: đủ chỉ số để biết ingest rate, HBase latency, queue depth, error rate

9.2 Alerting rule tối thiểu
Bước: giả lập lỗi, ví dụ HBase write error, collector backlog
Kỳ vọng: alert bắn đúng, không false positive quá nhiều

9.3 SLO dashboard
Bước: đo availability, latency, error rate trong test run
Kỳ vọng: có dashboard tối thiểu cho go live

---

# 10. Gợi ý cách tổ chức test case thành “test suite” chạy được

Bạn có thể gom thành 4 suite theo vòng đời:

10.1 Suite A, Pre merge
helm lint, helm template snapshot, schema validate

10.2 Suite B, Ephemeral cluster CI
install clean, smoke e2e ingest, basic HBase read write

10.3 Suite C, Upgrade regression
upgrade, rollback, node drain, PDB

10.4 Suite D, Performance and cost
latency benchmark, compaction stress, IOPS saturation

--- 
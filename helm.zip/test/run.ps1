param(
  [string]$NS = "pp-test",
  [string]$REL = "pp",
  [string]$CHART = "C:\\Sk\\hbaseCluster\\helm\\pinpoint-stack",
  [string]$VALUES = "C:\\Sk\\hbaseCluster\\helm\\pinpoint-stack\\values.yaml",
  [string]$AKS_RG = "TuanLN2-RG",
  [string]$AKS_NAME = "pinpoint",
  [switch]$CleanNamespace,
  [int]$TimeoutMinutes = 30
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info([string]$msg) {
  Write-Host "[INFO] $msg"
}

function Run([string]$cmd, [string]$outfile) {
  Write-Info $cmd
  $out = Invoke-Expression $cmd 2>&1 | Out-String
  $out | Out-File -FilePath $outfile -Encoding utf8
}

$timestamp = Get-Date -Format "yyyy-MM-dd_HHmm"
$logDir = Join-Path -Path "logs" -ChildPath $timestamp
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

Write-Info "Logs: $logDir"
Write-Info "NS=$NS REL=$REL CHART=$CHART VALUES=$VALUES"

# Suite A: Pre-checks (tool versions, lint, template)
Run "helm version" (Join-Path $logDir "helm-version.txt")
Run "kubectl version --client" (Join-Path $logDir "kubectl-version.txt")

Run "helm lint $CHART" (Join-Path $logDir "helm-lint.txt")

$renderPath = Join-Path $logDir "render.yaml"
Run "helm template $REL $CHART -n $NS -f $VALUES" $renderPath

# Simple greps (PowerShell equivalents)
Run "Select-String -Path `"$renderPath`" -Pattern 'image:'" (Join-Path $logDir "grep-image.txt")
Run "Select-String -Path `"$renderPath`" -Pattern 'selector:'" (Join-Path $logDir "grep-selector.txt")
Run "Select-String -Path `"$renderPath`" -Pattern 'kind: PersistentVolumeClaim'" (Join-Path $logDir "grep-pvc.txt")

$timeout = "${TimeoutMinutes}m"

# Suite B: Install & smoke theo flow backend → schema-init → collector
if ($CleanNamespace) {
  try {
    Write-Info "Deleting namespace $NS (wait=true)"
    kubectl delete ns $NS --wait=true | Out-Null
  } catch {
    Write-Info "Namespace delete returned error (can be OK if not found): $($_.Exception.Message)"
  }
}

Write-Info "Ensuring namespace exists (force create): $NS"
try {
  kubectl create ns $NS | Out-Null
} catch {
  Write-Info "Namespace create returned error (can be OK if AlreadyExists): $($_.Exception.Message)"
}

# If release exists, uninstall it (PoC: luôn cài mới). Nếu không, bỏ qua lỗi.
try {
  Run "helm status $REL -n $NS" (Join-Path $logDir "helm-status-before.txt")
  Run "helm uninstall $REL -n $NS" (Join-Path $logDir "helm-uninstall.txt")
} catch {
  Write-Info "helm uninstall skipped (release not found or not loaded): $($_.Exception.Message)"
}

# 1) Install backend only: HDFS + ZooKeeper + HBase (collector/schemaInit/pinpoint app tắt)
$cmdInstallBackend = "helm install $REL $CHART -n $NS -f $VALUES --create-namespace " +
                     "--set collector.enabled=false --set schemaInit.enabled=false --set pinpoint.enabled=false " +
                     "--wait --timeout $timeout"
Run $cmdInstallBackend (Join-Path $logDir "helm-install-backend.txt")

# 2) Chạy schema-init job một lần
$cmdSchemaOn = "helm upgrade $REL $CHART -n $NS -f $VALUES " +
               "--set schemaInit.enabled=true --set collector.enabled=false --set pinpoint.enabled=false " +
               "--wait --timeout $timeout"
Run $cmdSchemaOn (Join-Path $logDir "helm-upgrade-schema-on.txt")

# (Tuỳ chọn) Tắt lại schemaInit để các lần upgrade sau không auto chạy hook
$cmdSchemaOff = "helm upgrade $REL $CHART -n $NS -f $VALUES " +
                "--set schemaInit.enabled=false --set collector.enabled=false --set pinpoint.enabled=false " +
                "--wait --timeout $timeout"
Run $cmdSchemaOff (Join-Path $logDir "helm-upgrade-schema-off.txt")

# 3) Bật collector sau khi backend + schema-init đã OK
$cmdCollectorOn = "helm upgrade $REL $CHART -n $NS -f $VALUES " +
                  "--set collector.enabled=true --set schemaInit.enabled=false --set pinpoint.enabled=false " +
                  "--wait --timeout $timeout"
Run $cmdCollectorOn (Join-Path $logDir "helm-upgrade-collector-on.txt")

Run "kubectl get all -n $NS -o wide" (Join-Path $logDir "k8s-all.txt")
Run "kubectl get pvc -n $NS -o wide" (Join-Path $logDir "k8s-pvc.txt")
Run "kubectl get events -n $NS --sort-by=.lastTimestamp" (Join-Path $logDir "k8s-events.txt")

# Post: helm state
Run "helm get values $REL -n $NS -a" (Join-Path $logDir "helm-values.txt")
Run "helm get manifest $REL -n $NS" (Join-Path $logDir "helm-manifest.yaml")
Run "helm history $REL -n $NS" (Join-Path $logDir "helm-history.txt")

Write-Info "Done. Artifacts saved to $logDir"
Write-Info "Next manual steps: Suite C (HBase shell) & Suite D (Collector ingest) in test/test_plan_detail.md"
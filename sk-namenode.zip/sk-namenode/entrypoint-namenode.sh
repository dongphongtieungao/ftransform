#!/bin/bash
set -euo pipefail

NAME_DIR=/hadoop/dfs/name

echo "[sk-namenode] Using HADOOP_HOME=${HADOOP_HOME:-<unset>}"
echo "[sk-namenode] HOSTNAME=${HOSTNAME}"

# Extract ordinal from pod name, e.g. pinpoint-stack-hdfs-namenode-0 / -1
ORDINAL="$(echo "${HOSTNAME:-}" | awk -F'-' '{print $NF}')"
echo "[sk-namenode] ORDINAL=${ORDINAL}"

if [ "${ORDINAL}" = "0" ]; then
  echo "[sk-namenode] I am nn1 (primary)."

  # Format if metadata directory is empty
  if [ ! -f "$NAME_DIR/current/VERSION" ]; then
    echo "[sk-namenode] NameNode not formatted yet (missing current/VERSION). Formatting..."
    hdfs namenode -format -force -nonInteractive
    echo "[sk-namenode] Format completed."
  else
    echo "[sk-namenode] NameNode already formatted. Skipping format."
  fi

else
  echo "[sk-namenode] I am nn2 (standby)."

  # Bootstrap standby from shared edits if no local metadata yet
  if [ ! -f "$NAME_DIR/current/VERSION" ]; then
    echo "[sk-namenode] Standby not bootstrapped yet. Bootstrapping from shared edits..."
    hdfs namenode -bootstrapStandby -force || true
    echo "[sk-namenode] BootstrapStandby completed (or already bootstrapped)."
  else
    echo "[sk-namenode] Standby already has metadata. Skipping bootstrap."
  fi
fi

echo "[sk-namenode] Starting ZKFC in background..."
hdfs zkfc &

echo "[sk-namenode] Starting NameNode..."
exec hdfs namenode
